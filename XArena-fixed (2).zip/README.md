# XArena

Android debug APK project. Build with GitHub Actions using the workflow in `.github/workflows/build.yml`.

Note: the current app is a basic UI demonstration; it does not yet implement remote device control.
