package com.xarena.remote;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad * 2, pad, pad);
        layout.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("XArena");
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF18243A);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("PHONE CONTROL");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF52627A);
        layout.addView(subtitle);

        status = new TextView(this);
        status.setText("Status: Disconnected");
        status.setTextSize(16);
        status.setTextColor(0xFF26364F);
        status.setPadding(0, pad * 2, 0, pad);
        layout.addView(status);

        Button connect = new Button(this);
        connect.setText("Connect");
        connect.setOnClickListener(v ->
            status.setText("Status: Waiting for user permission")
        );
        layout.addView(connect);

        Button disconnect = new Button(this);
        disconnect.setText("Disconnect");
        disconnect.setOnClickListener(v ->
            status.setText("Status: Disconnected")
        );
        layout.addView(disconnect);

        TextView note = new TextView(this);
        note.setText("This build is the corrected app foundation. Remote screen sharing and control still need to be implemented with the target user's explicit permission.");
        note.setTextSize(13);
        note.setTextColor(0xFF596579);
        note.setPadding(0, pad * 2, 0, 0);
        layout.addView(note);

        setContentView(layout);
    }
}
